// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Get all navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Add click event listener to each link
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            // Get target section
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                // Calculate offset for fixed navbar
                const navbarHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetSection.offsetTop - navbarHeight;
                
                // Smooth scroll to target
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Highlight active navigation link on scroll
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section');
        const navbarHeight = document.querySelector('.navbar').offsetHeight;
        const currentPos = window.scrollY + navbarHeight + 50;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionBottom = sectionTop + section.offsetHeight;
            const sectionId = section.getAttribute('id');
            const correspondingLink = document.querySelector(`a[href="#${sectionId}"]`);
            
            if (currentPos >= sectionTop && currentPos <= sectionBottom) {
                // Remove active class from all links
                navLinks.forEach(link => link.classList.remove('active'));
                // Add active class to current link
                if (correspondingLink) {
                    correspondingLink.classList.add('active');
                }
            }
        });
    });
    
    // Dynamic opacity for About section based on scroll
    window.addEventListener('scroll', function() {
        const aboutSection = document.querySelector('#about');
        const heroSection = document.querySelector('#home');
        
        if (aboutSection && heroSection) {
            const heroHeight = heroSection.offsetHeight;
            const scrollY = window.scrollY;
            const windowHeight = window.innerHeight;
            
            // Start fading in when about section comes into view
            const aboutTop = aboutSection.offsetTop;
            const scrollProgress = scrollY - (aboutTop - windowHeight);
            const maxScroll = windowHeight * 0.8; // Distance over which to fade in
            
            // Calculate overlay opacity (1 to 0.7)
            let overlayOpacity = 1 - (scrollProgress / maxScroll) * 0.3;
            overlayOpacity = Math.max(0.7, Math.min(1, overlayOpacity));
            
            // Apply overlay opacity to ::before pseudo-element
            const beforeElement = aboutSection.querySelector('::before') || aboutSection;
            aboutSection.style.setProperty('--overlay-opacity', overlayOpacity);
        }
    });
    
    // Dynamic opacity for Offer section based on scroll (white background transition)
    window.addEventListener('scroll', function() {
        const offerSection = document.querySelector('#offer');
        const aboutSection = document.querySelector('#about');
        
        if (offerSection && aboutSection) {
            const scrollY = window.scrollY;
            const windowHeight = window.innerHeight;
            
            // Start fading in when offer section comes into view
            const offerTop = offerSection.offsetTop;
            const scrollProgress = scrollY - (offerTop - windowHeight);
            const maxScroll = windowHeight * 0.8; // Distance over which to fade in
            
            // Calculate opacity (0 to 1.0)
            let opacity = (scrollProgress / maxScroll);
            opacity = Math.max(0, Math.min(1, opacity));
            
            offerSection.style.opacity = opacity;
        }
    });
    
    // Navbar background opacity on scroll
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        const scrolled = window.scrollY;
        
        if (scrolled > 100) {
            navbar.style.background = 'rgba(0, 0, 0, 0.95)';
        } else {
            navbar.style.background = 'rgba(0, 0, 0, 0.9)';
        }
    });
    
    // Contact form submission
    const contactForm = document.querySelector('#contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const name = this.querySelector('input[type="text"]').value;
            const email = this.querySelector('input[type="email"]').value;
            const message = this.querySelector('textarea').value;
            
            // Simple validation
            if (name && email && message) {
                alert('Dziękujemy za wiadomość! Skontaktujemy się z Państwem wkrótce.');
                this.reset();
            } else {
                alert('Proszę wypełnić wszystkie pola formularza.');
            }
        });
    }
    
    // End of DOMContentLoaded
});

// ── Animated Travel Line ──
// Three-phase train with pauses between sections:
//   Phase 1: hero subtitle → left → down → right ("O nas" title end)   [white]
//   Pause
//   Phase 2: right (turn col) → down → left ("Oferta" title left)       [black]
//   Pause
//   Phase 3: further left (past bento) → down → right (under logo)      [white]
function initTravelLine() {
    const wrapper           = document.querySelector('.travel-line-wrapper');
    const subtitleSpan      = document.querySelector('.subtitle-measure');
    const aboutTitleSpan    = document.querySelector('.about-title-measure');
    const offerTitleSpan    = document.querySelector('.offer-title-measure');
    const contactLogoEl     = document.getElementById('contact-logo-anchor');
    const aboutSection      = document.querySelector('#about');
    const offerSection      = document.querySelector('#offer');
    const contactSection    = document.querySelector('#contact');
    const pathWhite         = document.getElementById('travel-line-path-white');
    const pathBlack         = document.getElementById('travel-line-path-black');
    const clipWhiteRectTop  = document.getElementById('clip-white-rect-top');
    const clipWhiteRectBot  = document.getElementById('clip-white-rect-bottom');
    const clipBlackRect     = document.getElementById('clip-black-rect');

    if (!wrapper || !subtitleSpan || !aboutTitleSpan || !offerTitleSpan ||
        !contactLogoEl || !aboutSection || !offerSection || !contactSection ||
        !pathWhite || !pathBlack) return;

    let totalLength       = 0;
    let lineLength        = 0;
    let p1 = 0, p2 = 0;
    let phase1EndScroll   = 1;
    let phase2StartScroll = 2, phase2EndScroll = 3;
    let phase3StartScroll = 4, phase3EndScroll = 5;

    function buildPath() {
        const wrapperRect     = wrapper.getBoundingClientRect();
        const spanRect        = subtitleSpan.getBoundingClientRect();
        const aboutTitleRect  = aboutTitleSpan.getBoundingClientRect();
        const offerTitleRect  = offerTitleSpan.getBoundingClientRect();
        const contactLogoRect = contactLogoEl.getBoundingClientRect();
        const offerRect       = offerSection.getBoundingClientRect();
        const contactRect     = contactSection.getBoundingClientRect();

        // Right-turn X: right edge of about-content + 20 px
        const aboutContent = aboutSection.querySelector('.about-content');
        const rightTurnX   = aboutContent
            ? aboutContent.getBoundingClientRect().right - wrapperRect.left + 20
            : wrapperRect.width * 0.75;

        // Left-turn X: left edge of offer container - 20 px, but at least 10px from wrapper edge
        const offerContainer = offerSection.querySelector('.section-container');
        const leftTurnXRaw   = offerContainer
            ? offerContainer.getBoundingClientRect().left - wrapperRect.left - 20
            : 40;
        const leftTurnX      = Math.max(10, leftTurnXRaw);

        // SVG coordinate space (relative to wrapper top-left)
        const subBottomY         = spanRect.bottom        - wrapperRect.top;
        const subLeftX           = spanRect.left          - wrapperRect.left;
        const subRightX          = spanRect.right         - wrapperRect.left;
        const aboutTitleBottomY  = aboutTitleRect.bottom  - wrapperRect.top;
        const aboutTitleRightX   = aboutTitleRect.right   - wrapperRect.left;
        const offerTopY          = offerRect.top          - wrapperRect.top;
        const offerTitleBottomY  = offerTitleRect.bottom  - wrapperRect.top;
        const offerTitleLeftX    = offerTitleRect.left    - wrapperRect.left;
        const contactTopY        = contactRect.top        - wrapperRect.top;
        const contactLogoBottomY = contactLogoRect.bottom - wrapperRect.top;
        const contactLogoRightX  = contactLogoRect.right  - wrapperRect.left;

        lineLength = Math.abs(subRightX - subLeftX) + 20;

        // Full path (10 points)
        const d = `M ${subRightX},${subBottomY} ` +
                  `L ${subLeftX},${subBottomY} ` +
                  `L ${subLeftX},${aboutTitleBottomY} ` +
                  `L ${aboutTitleRightX},${aboutTitleBottomY} ` +
                  `L ${rightTurnX},${aboutTitleBottomY} ` +
                  `L ${rightTurnX},${offerTitleBottomY} ` +
                  `L ${offerTitleLeftX},${offerTitleBottomY} ` +
                  `L ${leftTurnX},${offerTitleBottomY} ` +
                  `L ${leftTurnX},${contactLogoBottomY} ` +
                  `L ${contactLogoRightX},${contactLogoBottomY}`;

        pathWhite.setAttribute('d', d);
        pathBlack.setAttribute('d', d);
        totalLength = pathWhite.getTotalLength();

        // Pause points (geometric, axis-aligned segments)
        p1 = Math.abs(subRightX - subLeftX) +
             Math.abs(aboutTitleBottomY - subBottomY) +
             Math.abs(aboutTitleRightX  - subLeftX);

        p2 = p1 +
             Math.abs(rightTurnX        - aboutTitleRightX) +
             Math.abs(offerTitleBottomY - aboutTitleBottomY) +
             Math.abs(rightTurnX        - offerTitleLeftX);

        const dashArr = `${lineLength} ${totalLength + lineLength}`;
        pathWhite.style.strokeDasharray = dashArr;
        pathBlack.style.strokeDasharray = dashArr;

        // Clip white-top: above offer section
        clipWhiteRectTop.setAttribute('x',      -9999);
        clipWhiteRectTop.setAttribute('y',      -9999);
        clipWhiteRectTop.setAttribute('width',   99999);
        clipWhiteRectTop.setAttribute('height',  offerTopY + 9999);
        // Clip white-bottom: contact section and below
        clipWhiteRectBot.setAttribute('x',      -9999);
        clipWhiteRectBot.setAttribute('y',       contactTopY);
        clipWhiteRectBot.setAttribute('width',   99999);
        clipWhiteRectBot.setAttribute('height',  99999);
        // Clip black: only offer section band
        clipBlackRect.setAttribute('x',      -9999);
        clipBlackRect.setAttribute('y',       offerTopY);
        clipBlackRect.setAttribute('width',   99999);
        clipBlackRect.setAttribute('height',  contactTopY - offerTopY);

        // Scroll thresholds
        const navH             = (document.querySelector('.navbar') || {offsetHeight: 0}).offsetHeight;
        const aboutAbsTop      = aboutSection.getBoundingClientRect().top   + window.scrollY;
        const offerAbsTop      = offerSection.getBoundingClientRect().top   + window.scrollY;
        const contactAbsTop    = contactSection.getBoundingClientRect().top + window.scrollY;
        const logoAbsBot       = contactLogoRect.bottom                     + window.scrollY;

        // Phase 1 ends when about section top reaches the navbar
        phase1EndScroll   = Math.max(1, aboutAbsTop - navH);
        // Phase 2 starts when offer section bottom edge first appears in viewport
        phase2StartScroll = Math.max(phase1EndScroll  + 1, offerAbsTop - window.innerHeight);
        // Phase 2 ends when offer section top reaches navbar (fully on screen)
        phase2EndScroll   = Math.max(phase2StartScroll + 1, offerAbsTop - navH);
        // Phase 3 starts immediately (no pause) — line travels while scrolling through offer content
        phase3StartScroll = phase2EndScroll;
        // Phase 3 ends when contact section top reaches navbar
        phase3EndScroll   = Math.max(phase3StartScroll + 1, contactAbsTop - navH);

        updateAnimation();
    }

    function updateAnimation() {
        const scrollY = window.scrollY;
        let frontPos;

        if (scrollY <= phase1EndScroll) {
            const p = Math.max(0, Math.min(1, scrollY / phase1EndScroll));
            frontPos = lineLength + (p1 - lineLength) * p;
        } else if (scrollY <= phase2StartScroll) {
            frontPos = p1;
        } else if (scrollY <= phase2EndScroll) {
            const p = Math.max(0, Math.min(1,
                (scrollY - phase2StartScroll) / (phase2EndScroll - phase2StartScroll)));
            frontPos = p1 + (p2 - p1) * p;
        } else if (scrollY <= phase3StartScroll) {
            frontPos = p2;
        } else {
            const p = Math.max(0, Math.min(1,
                (scrollY - phase3StartScroll) / (phase3EndScroll - phase3StartScroll)));
            frontPos = p2 + (totalLength - p2) * p;
        }

        const offset = -(frontPos - lineLength);
        pathWhite.style.strokeDashoffset = offset;
        pathBlack.style.strokeDashoffset = offset;
    }

    buildPath();
    window.addEventListener('scroll', updateAnimation, { passive: true });
    window.addEventListener('resize', buildPath);
}

window.addEventListener('load', initTravelLine);